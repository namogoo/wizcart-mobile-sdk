//
//  WizCart.h
//  WizCart
//
//  Created by Amir Zucker on 18/05/2020.
//  Copyright © 2020 Namogoo. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for WizCart.
FOUNDATION_EXPORT double WizCartVersionNumber;

//! Project version string for WizCart.
FOUNDATION_EXPORT const unsigned char WizCartVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WizCart/PublicHeader.h>


